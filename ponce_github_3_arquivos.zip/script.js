const entities = [
 {name:"cliente",category:"cadastro",label:"Cadastro",description:"Armazena os dados cadastrais dos clientes que realizam compras da Ponce.",fields:["id_cliente — identificador do cliente (PK prevista).","nome e dados de contato — informações pessoais sujeitas à LGPD.","cpf_cnpj — documento do cliente; há regra de anonimização e retenção fiscal.","ativo — indicador para exclusão lógica, conforme convenção do projeto.","Relaciona-se com venda."]},
 {name:"vendedor",category:"cadastro",label:"Cadastro",description:"Identifica os vendedores responsáveis pelo atendimento e registro das vendas.",fields:["id_vendedor — identificador do vendedor (PK prevista).","nome, telefone e email — campos mencionados no RF08.","ativo — vendedor inativo não pode receber nova venda.","Relaciona-se com venda e, quando aplicável, usuário."]},
 {name:"produto",category:"cadastro",label:"Cadastro",description:"Mantém o catálogo de produtos comercializados, sem controle de saldo de estoque físico.",fields:["id_produto — identificador do produto (PK prevista).","codigo_produto — código comercial com restrição UNIQUE.","nome e descricao — identificação do produto.","id_fornecedor — vínculo com fornecedor.","preco_custo e preco_venda — valores monetários; DECIMAL(10,2) recomendado.","ativo — produto inativo não pode entrar em nova venda."]},
 {name:"fornecedor",category:"cadastro",label:"Cadastro",description:"Registra os fornecedores associados aos produtos e às compras realizadas.",fields:["id_fornecedor — identificador do fornecedor (PK prevista).","Dados cadastrais do fornecedor — detalhamento físico deve ser confirmado no DDL.","Relaciona-se com produto e compra."]},
 {name:"venda",category:"operacao",label:"Operação",description:"Registra o processo de venda, do início à confirmação ou cancelamento.",fields:["id_venda — identificador da venda (PK prevista).","id_cliente e id_vendedor — referências aos cadastros correspondentes.","data_venda — data e hora da venda (DATETIME).","valor_desconto — desconto aplicado à venda.","canal_origem — canal FORMULARIO ou EMAIL; continuidade por WhatsApp mantém a mesma venda.","status — inclui estados INICIADO, VENDIDO e CANCELADO.","data_cancelamento — preenchida quando a venda é cancelada.","valor_total — valor derivado da soma dos itens menos desconto."]},
 {name:"item_venda",category:"operacao",label:"Operação",description:"Detalha os produtos e quantidades que compõem cada venda.",fields:["id_item_venda — identificador do item (PK prevista).","id_venda e id_produto — vínculos com venda e produto.","quantidade — quantidade comercializada.","preco_unitario — preço praticado no momento da inclusão; preserva histórico.","Regra: venda finalizada sem itens é rejeitada."]},
 {name:"compra",category:"operacao",label:"Operação",description:"Registra compras de produtos realizadas sob demanda, sem gerar saldo de estoque.",fields:["id_compra — identificador da compra (PK prevista).","id_fornecedor — vínculo com fornecedor.","data_compra — data da compra.","valor_total — total da compra, conforme composição dos itens.","Regra: exclusão física de compra é negada; confirmação deve ocorrer em transação."]},
 {name:"item_compra",category:"operacao",label:"Operação",description:"Entidade associativa que discrimina os produtos e valores de cada compra.",fields:["id_item_compra — identificador do item (PK prevista).","id_compra e id_produto — vínculos com compra e produto.","quantidade e preco_unitario — dados do item de compra.","Regra: confirmar compra sem item_compra é rejeitado."]},
 {name:"nota_fiscal",category:"operacao",label:"Operação",description:"Armazena os dados da nota fiscal já emitida por sistema externo; o projeto não emite NF.",fields:["id_nota_fiscal — identificador padronizado da nota (PK).","id_venda — venda à qual a nota está vinculada.","numero, chave e data_emissao — dados de identificação fiscal.","valor — deve corresponder ao valor_total da venda.","id_usuario_arquivamento e data_arquivamento — rastreiam o arquivamento.","UPDATE e DELETE de nota emitida são negados."]},
 {name:"usuario",category:"seguranca",label:"Segurança",description:"Controla a autenticação e o perfil de acesso dos usuários do sistema.",fields:["id_usuario — identificador do usuário (PK prevista).","login — identificador de acesso único.","senha — armazenar somente hash Argon2id ou bcrypt; nunca texto puro.","perfil — define permissões por RBAC.","id_vendedor — vínculo opcional com vendedor, quando aplicável.","ativo — usuário inativo não autentica."]},
 {name:"lancamento_financeiro",category:"financeiro",label:"Financeiro",description:"Registra entradas, saídas e estornos para acompanhamento gerencial do fluxo de caixa.",fields:["id_lancamento_financeiro — identificador do lançamento (PK prevista).","tipo — natureza do lançamento (ENTRADA, SAIDA ou ESTORNO, conforme regra).","valor — valor monetário do lançamento.","id_venda ou id_compra — origem relacionada, quando aplicável.","data_lancamento — data do registro.","Correções de valor devem ocorrer por lançamento de estorno, não por alteração/exclusão."]},
 {name:"log_auditoria",category:"seguranca",label:"Segurança",description:"Mantém trilha de auditoria das operações críticas, com histórico append-only.",fields:["id_log_auditoria — identificador do registro (PK prevista).","id_usuario — usuário responsável pela operação.","tabela_afetada e id_registro_afetado — alvo da alteração.","operacao — INSERT, UPDATE ou DELETE.","valor_anterior e valor_novo — conteúdo antes e depois da operação (JSON, conforme recomendação).","data_hora — momento da operação.","UPDATE e DELETE no log devem ser negados."]}
];

const grid = document.getElementById("entityGrid");
const searchInput = document.getElementById("searchInput");
const categoryFilter = document.getElementById("categoryFilter");
const count = document.getElementById("entityCount");
const modal = document.getElementById("entityModal");

function renderEntities(){
  const q = searchInput.value.trim().toLocaleLowerCase("pt-BR");
  const category = categoryFilter.value;
  const filtered = entities.filter(e => (category === "all" || e.category === category) &&
    (e.name + " " + e.description + " " + e.fields.join(" ")).toLocaleLowerCase("pt-BR").includes(q));
  count.textContent = `${filtered.length} ${filtered.length === 1 ? "entidade" : "entidades"}`;
  grid.innerHTML = filtered.length ? filtered.map(e => `
    <article class="entity-card">
      <div class="card-meta"><span class="tag">${e.label}</span><span class="muted">▦</span></div>
      <h3>${e.name}</h3><p>${e.description}</p>
      <div class="card-bottom"><span>${e.fields.length} observações</span><button class="details-link" data-entity="${e.name}">Ver detalhes ↗</button></div>
    </article>`).join("") : `<p class="muted">Nenhuma entidade encontrada. Tente outro termo ou filtro.</p>`;
}
function openEntity(name){
  const e = entities.find(item => item.name === name);
  if(!e) return;
  document.getElementById("modalTitle").textContent = e.name;
  document.getElementById("modalCategory").textContent = e.label.toUpperCase();
  document.getElementById("modalDescription").textContent = e.description;
  document.getElementById("modalFields").innerHTML = e.fields.map(f => `<li>${f}</li>`).join("");
  modal.hidden = false;
  document.body.style.overflow = "hidden";
}
function closeModal(){ modal.hidden = true; document.body.style.overflow = ""; }

searchInput.addEventListener("input", renderEntities);
categoryFilter.addEventListener("change", renderEntities);
grid.addEventListener("click", e => { const btn=e.target.closest("[data-entity]"); if(btn) openEntity(btn.dataset.entity); });
modal.addEventListener("click", e => { if(e.target.matches("[data-close]")) closeModal(); });
document.addEventListener("keydown", e => { if(e.key === "Escape" && !modal.hidden) closeModal(); });

const themeToggle = document.getElementById("themeToggle");
const savedTheme = localStorage.getItem("ponce-theme");
if(savedTheme) document.documentElement.dataset.theme = savedTheme;
themeToggle.textContent = document.documentElement.dataset.theme === "dark" ? "☀" : "☾";
themeToggle.addEventListener("click", () => {
  const next = document.documentElement.dataset.theme === "dark" ? "light" : "dark";
  document.documentElement.dataset.theme = next;
  localStorage.setItem("ponce-theme", next);
  themeToggle.textContent = next === "dark" ? "☀" : "☾";
});
renderEntities();
